import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { Employee } from './Employee';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private url = 'api/heroes';

  constructor(private http: HttpClient,) { }

// Get all the Employees(get)
  getEmps (): Observable<any> {
    return this.http.get<Employee[]>(this.url)
  }
// Get Employees By Id(get by ID)
  getUserbyId(id: number): Observable<any> {
    const url = `${this.url}/${id}`;
    return this.http.get<any>(url)
  }
// Update the Emp Name(put)
  updateHero(EmployeeList:any) {
    return this.http.put(this.url, EmployeeList)
  }

}
