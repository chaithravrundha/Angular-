import { Employee } from '../../../Employee';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-childemployee-details',
  templateUrl: './child.employee-details.component.html',
  styleUrls: ['./child.employee-details.component.css']
})
export class ChildEmployeeDetailsComponent implements OnInit {
  @Input() EmployeeList: Employee;
  @Output() save= new EventEmitter<any>();
  @Output() goBack= new EventEmitter();

  goBackClicked(): void {
    this.goBack.emit();
  }

  constructor() { }

  ngOnInit(): void {

  }

  saveClicked(): void {
    this.save.emit(this.EmployeeList);
    }
}
