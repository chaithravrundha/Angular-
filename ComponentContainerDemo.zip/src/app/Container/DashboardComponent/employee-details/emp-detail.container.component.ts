import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable, of } from 'rxjs';
import { Employee } from 'src/app/Employee';
import { EmployeeService } from 'src/app/employee.service';
Employee

@Component({
  selector: 'app-emp-detail',
  templateUrl: './emp-detail.container.component.html',
  styleUrls: [ ],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EmpDetailContainerComponent {
  emp: Observable<any>

  constructor(
    private route: ActivatedRoute,
    private empService: EmployeeService,
    private location: Location
  ) {
    this.getUserbyId();
  }

  getUserbyId(): void {
      const id = +this.route.snapshot.paramMap.get('id');
      this.emp = this.empService.getUserbyId(id);
    }

    goBack(): void {
      this.location.back();
    }

    save(EmployeeList:any): void {
      // this.heroService.updateHero(EmployeeList).subscribe(()=> this.location.back())
      this.empService.updateHero(EmployeeList).subscribe(()=> this.goBack());
    }
}
