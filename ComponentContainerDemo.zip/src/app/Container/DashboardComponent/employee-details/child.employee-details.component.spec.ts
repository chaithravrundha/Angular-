import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildEmployeeDetailsComponent } from './child.employee-details.component';

describe('EmployeeDetailsComponent', () => {
  let component: ChildEmployeeDetailsComponent;
  let fixture: ComponentFixture<ChildEmployeeDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildEmployeeDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildEmployeeDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
