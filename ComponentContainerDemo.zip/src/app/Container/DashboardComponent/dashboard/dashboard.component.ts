import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/Employee';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  EmployeeList: Employee[] = [];

  constructor(private empService: EmployeeService) { }

  ngOnInit(): void {
    this.getEmps();
  }

  getEmps(): void {
    this.empService.getEmps()
      .subscribe(res => this.EmployeeList = res.slice(1, 5));
  }

}
