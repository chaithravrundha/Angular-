import { Employee } from './Employee';


export const EMPLOYEE: Employee[] = [
    { id: 11, name: 'Ashish' },
    { id: 12, name: 'Indiresh' },
    { id: 13, name: 'Rajesh' },
    { id: 14, name: 'Onkar' },
    { id: 15, name: 'Chaithra' },
    { id: 16, name: 'Selva' },
];